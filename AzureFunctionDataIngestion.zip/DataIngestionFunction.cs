using System;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace AzureFunctionDataIngestion
{
    public class DataIngestionFunction
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<DataIngestionFunction> _logger;
        private readonly BlobServiceClient _blobServiceClient;

        public DataIngestionFunction(HttpClient httpClient, ILogger<DataIngestionFunction> logger, BlobServiceClient blobServiceClient)
        {
            _httpClient = httpClient;
            _logger = logger;
            _blobServiceClient = blobServiceClient;
        }

        [Function("DataIngestionFunction")]
        public async Task RunAsync([TimerTrigger("0 0 * * * *")] TimerInfo timerInfo) 
        {
            _logger.LogInformation($"Data ingestion started at: {DateTime.UtcNow}");

            try
            {
                // 1. Call API (or replace with DB call)
                string apiUrl = Environment.GetEnvironmentVariable("SourceApiUrl");
                var response = await _httpClient.GetAsync(apiUrl);
                response.EnsureSuccessStatusCode();

                var json = await response.Content.ReadAsStringAsync();
                _logger.LogInformation("Data retrieved from API.");

                // 2. (Optional) Transform data
                using var jsonDoc = JsonDocument.Parse(json);
                string transformedData = JsonSerializer.Serialize(jsonDoc, new JsonSerializerOptions { WriteIndented = true });

                // 3. Write to Azure Data Lake (Blob Storage)
                string containerName = "raw-data";
                string blobName = $"ingestion-{DateTime.UtcNow:yyyyMMddHHmmss}.json";

                var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
                await containerClient.CreateIfNotExistsAsync();

                var blobClient = containerClient.GetBlobClient(blobName);

                using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(transformedData));
                await blobClient.UploadAsync(stream, overwrite: true);

                _logger.LogInformation($"Data written to Data Lake as {blobName}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error during ingestion: {ex.Message}", ex);
                throw;
            }

            _logger.LogInformation($"Data ingestion completed at: {DateTime.UtcNow}");
        }
    }
}
